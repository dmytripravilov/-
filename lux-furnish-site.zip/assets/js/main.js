
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', e=>{
      const id=a.getAttribute('href').slice(1), el=document.getElementById(id);
      if(el){e.preventDefault(); el.scrollIntoView({behavior:'smooth'});}
    });
  });
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('on'); io.unobserve(e.target); } });
  }, {threshold:.12});
  document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(!prefersReduced){
    const art = document.querySelector('.hero-art');
    window.addEventListener('scroll', ()=>{
      const y = window.scrollY * 0.15;
      if(art){ art.style.transform = `translateY(${y}px)`; }
    }, {passive:true});
  }
  const form = document.getElementById('contact-form');
  const status = document.getElementById('form-status');
  if(form){ form.addEventListener('submit', ()=>{ status.textContent='Надсилаємо…'; }); }
});
