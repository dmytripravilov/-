# Lux•Furnish — portfolio-grade static site
Luxury dark UI, reveal animations, parallax hero, custom SVG art only for this site.
SEO: OG + JSON‑LD. Mobile‑first, Lighthouse‑friendly.

Quick start:
1) Set your email in form action.
2) Replace contacts/links.
3) Swap SVG previews for real photos if desired.
Push to GitHub Pages. MIT.
